"""
coded by Fahrettin Kuran, Gulum Tanircan (Gülüm Tanırcan), Elham Pashaei, 2022

                             Bogazici University
                             fahrettin.kuran@boun.edu.tr
                             
                             Bogazici University
                             birgore@boun.edu.tr
                             
                             Istanbul Gelisim University
                             epashaei@gelisim.edu.tr

% GB model based on the following citation

Kuran, F., Tanircan G., Pashaei E. (2023). 
“Performance evaluation of machine learning techniques in predicting cumulative
 absolute velocity.” Soil Dynamics and Earthquake Engineering, ...

Provides a regional ground-motion prediction model based on Turkiye for geomean
 CAV of horizontal components along with performance error metrics.
###############################################################################
Input variables
M = Moment Magnitude
Vs30 = Shear wave velocity (m/s)
Rjb = Joyner-Boore distance (km)
Style-of-faulting (SoF) = 0.51751525 for Strike-slip fault & Mw<5.5
                        = 0.44887250 for Normal fault      & Mw<5.5
                        = 0.56944444 for Strike-slip fault & Mw≥5.5
                        = 0.42857143 for Normal fault      & Mw≥5.5
                        
Note: Predicting CAV for 3.5≤Mw≤5.4 earthquakes, use file_one.xlsx, gmm_one.fge, 
and scaled_variables_one.fge files, while file_two.xlsx, gmm_two.fge, and 
scaled_variables_two.fge files are going to be used for 5.5≤Mw≤7.6 earthquakes.

Output Variables
CAV = Cumulative absolute velocity (cm/s)

MSE =  Mean Squared Error
RMSE = Root Mean Squared Error
MAE = Mean Absolute Error
MAPE = Mean Absolute Percentage Error
R = Correlarion coefficient

Note: Y_pred (CAV_predicted) values obtained as output are normalized output. 
So, inverse min-max normalization should be applied to see real values
of Y_pred (CAV_predicted).

min_max normalizatiom: Y_scaled = (Y-Y_min)/(Y_max-Y_min)
                                  Y_min = 0.155240 cm/s        for Mw<5.5
                                  Y_mox = 341.561533 cm/s      for Mw<5.5
                                  Y_min = 0.641144 cm/s        for Mw≥5.5
                                  Y_mox = 1394.7038975 cm/s    for Mw≥5.5
"""

# LIBRARIES
import pandas as pd
import numpy as np
from sklearn import metrics
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_percentage_error
from sklearn.preprocessing import MinMaxScaler
from scipy.stats import pearsonr
import pickle

# Gradient Boosting Groum Motion Model
# fit the model to the training data (learn the coefficients)
gb = GradientBoostingRegressor()
filename = '../GB_GMM/gmm_one.fge'
gb = pickle.load(open(filename, 'rb'))

# DATA PROCESSING
# read file
data = pd.read_excel('file_one.xlsx')
print(data)
data.head()
cn = list(data.columns.values)

# check the shape of the DataFrame (rows, columns)
data.shape
scaler = MinMaxScaler()
scaler = pickle.load(open('../GB_GMM/scaled_variables_one.fge', 'rb'))
data = scaler.transform(data)
data=pd. DataFrame (data, columns=cn)

X = data.iloc[:,0:4]
X_scaled=X
Y_scaled = data['CAV']
print(X_scaled)
print(Y_scaled)

# make predictions on the testing set
Y_pred = gb.predict(X_scaled)

###ERRORS
# calculate Mean Absolute Error (MAE)
MAE = (metrics.mean_absolute_error(Y_scaled, Y_pred)).round(8)
print(MAE)

# calculate Mean Absolute Percentage Error (MAPE)
MAPE = mean_absolute_percentage_error(Y_scaled, Y_pred).round(8)
print(MAPE)

# calculate Mean Squared Error (MSE)
MSE = (metrics.mean_squared_error(Y_scaled, Y_pred)).round(8)
print(MSE)

# calculate Root Mean Squared Error (RMSE)
RMSE = (np.sqrt(metrics.mean_squared_error(Y_scaled, Y_pred))).round(8)
print(RMSE)

# calculate correlarion coefficient (R)
R = pearsonr(Y_scaled, Y_pred)
print(R)
###############################################################################